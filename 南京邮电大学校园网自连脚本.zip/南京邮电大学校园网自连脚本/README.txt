1. msg.txt文件用于存储校园网账户和密码
第一行：账户（学号）
第二行：密码
第三行：校园网名称（NJUPT-CHINANET 或 NJUPT-CMCC）注：NJUPT不行

2. 需在D盘根目录下创建utils文件夹，并将 msg.txt 和 msedgedriver.exe 存入其中
保证路径为：C:/utils/msedgedriver.exe 和 C:/utils/msg.txt 即可

3. 设置开机自动
将 AutoConnectNJUPT-CHINANET-CMCC.exe 存放在C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\目录下，即可开机自启

注：本脚本是基于Edge浏览器进行的自动化操作，因此，需要安装Edge浏览器才行，且电脑不能睡眠，睡眠状态下，脚本不会运行
本脚本去除了所有报错提示，请保证输入的账号密码校园网名称正确，此为自动化脚本，旨在自动连接校园网，以及起到断网自动连接的作用